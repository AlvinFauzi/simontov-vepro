<?php

return [
    'month' => [
        "jan" => "January",
        "feb" => "February",
        "mar" => "March",
        "apr" => "April",
        "may" => "May",
        "jun" => "June",
        "jul" => "July",
        "aug" => "August",
        "sep" => "September",
        "oct" => "October",
        "nov" => "November",
        "dec" => "December",
    ],
    'day' => [
        "su" => "Sun",
        "mo" => "Mon",
        "tu" => "Tue",
        "we" => "Wed",
        "th" => "Thu",
        "fr" => "Fri",
        "sa" => "Sat",
    ],
    'button' => [
        'cancel' => 'Cancel',
        'apply' => 'Apply',
    ]


];
