<?php

return [
    'month' => [
        "jan" => "Janiari",
        "feb" => "Februari",
        "mar" => "Maret",
        "apr" => "April",
        "may" => "Mei",
        "jun" => "Juni",
        "jul" => "Juli",
        "aug" => "Agustus",
        "sep" => "September",
        "oct" => "Oktober",
        "nov" => "November",
        "dec" => "Desember",
    ],
    'day' => [
        "su" => "Min",
        "mo" => "Sen",
        "tu" => "Sel",
        "we" => "Rab",
        "th" => "Kam",
        "fr" => "Jum",
        "sa" => "Sab",
    ],
    'button' => [
        'cancel' => 'Batal',
        'apply' => 'Terapkan',
    ]


];
