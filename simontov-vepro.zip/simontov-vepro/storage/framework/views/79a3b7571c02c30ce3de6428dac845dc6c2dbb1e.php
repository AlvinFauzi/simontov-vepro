<nav class="horizontalMenu clearfix">
    <ul class="horizontalMenu-list">
        <li aria-haspopup="true">
            <a href="<?php echo e(route('home')); ?>">
                <i class="fe fe-home"></i>
                <?php echo e(trans('lang.dashboard')); ?>

            </a>
        </li>

        <li aria-haspopup="true">
            <a href="<?php echo e(route('flowrate.index')); ?>">
                <i class="fe fe-activity"></i>
                <?php echo e(trans('lang.flowrate')); ?>

            </a>
        </li>
        <?php if(auth()->check() && auth()->user()->hasRole('superAdmin')): ?>
            <li aria-haspopup="true">
                <a href="<?php echo e(route('alarm.index')); ?>">
                    <i class="fe fe-bell"></i>
                    Alarm
                </a>
            </li>
        <?php endif; ?>

        <li aria-haspopup="true">
            <a href="<?php echo e(route('user.index')); ?>">
                <i class="fe fe-users"></i>
                <?php echo e(trans('lang.user')); ?>

            </a>
        </li>

    </ul>
</nav>
<?php /**PATH C:\xampp\htdocs\simontov-vepro\simontov-vepro\resources\views/components/horizontal-menu.blade.php ENDPATH**/ ?>