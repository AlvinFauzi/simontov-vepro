<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="UTF-8">
    <meta name='viewport' content='width=device-width, initial-scale=1.0, user-scalable=0'>
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <link rel="shortcut icon" type="image/x-icon" href="<?php echo e(asset('images/logo_sedang.png')); ?>" />
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <meta name="app-url" content="<?php echo e(env('MIX_URL')); ?>">
    <title><?php echo e(str_replace('-', ' ', config('app.name', 'Laravel'))); ?></title>
    <link href="<?php echo e(asset('css/auth.css')); ?>" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/style.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/icons.css')); ?>">
    <link id="theme" rel="stylesheet" type="text/css" media="all" href="<?php echo e(asset('assets/colors/color1.css')); ?>" />
</head>

<body>
    <div class="login-img">
        <div id="global-loader">
            <img src="<?php echo e(asset('assets')); ?>/images/loader.svg" class="loader-img" alt="Loader">
        </div>
        <div class="page">
            <div class="">
                <?php echo $__env->yieldContent('content'); ?>
            </div>
        </div>
    </div>
    <script src="<?php echo e(asset('js/auth.js')); ?>"></script>

</body>

</html>
<?php /**PATH C:\xampp\htdocs\simontov-vepro\resources\views/layouts/auth.blade.php ENDPATH**/ ?>