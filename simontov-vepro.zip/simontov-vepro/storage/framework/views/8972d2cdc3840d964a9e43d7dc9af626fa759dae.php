<a class="nav-link icon text-uppercase" id="activeLanguage" data-bs-toggle="dropdown"
    data-lang="<?php echo e(session()->get('locale') ?? 'ID'); ?>">
    <?php if(session()->get('locale') === 'en'): ?>
        <i class="flag flag-gb"></i>
    <?php else: ?>
        <i class="flag flag-id"></i>
    <?php endif; ?>
</a>
<div class="dropdown-menu dropdown-menu-end dropdown-menu-arrow ">
    <a href="<?php echo e(route('setLocale', ['id'])); ?>" class="dropdown-item text-center text-muted"><i
            class="flag flag-id"></i> <?php echo e(__('lang.id')); ?></a>
    <a href="<?php echo e(route('setLocale', ['en'])); ?>" class="dropdown-item text-center text-muted"><i
            class="flag flag-gb"></i> <?php echo e(__('lang.en')); ?></a>
</div>
<?php /**PATH C:\xampp\htdocs\simontov-vepro\simontov-vepro\resources\views/components/set-language.blade.php ENDPATH**/ ?>