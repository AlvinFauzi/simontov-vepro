


<?php $__env->startSection('content'); ?>
    <div class="container-login100">
        <div class="wrap-login100 p-0">
            <div class="card-body">
                <form class="login100-form validate-form needs-validation" method="POST" action="<?php echo e(route('login')); ?>"
                    novalidate>
                    <?php echo csrf_field(); ?>
                    <div class="col col-login mx-auto">
                        <div class="text-center">
                            <img src="<?php echo e(asset('images/logo_kecil.png')); ?>" class="img-fluid mb-lg-3" alt="">
                        </div>
                    </div>
                    <span class="login100-form-title">
                        <?php echo e(__('Login')); ?>

                    </span>
                    <div class="wrap-input100 validate-input">
                        <input class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="text" name="email" required
                            placeholder="<?php echo e(trans('lang.email')); ?>" value="<?php echo e(old('email')); ?>">
                        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback" role="alert">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="wrap-input100 validate-input">
                        <input class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="password" name="password"
                            required placeholder="<?php echo e(trans('lang.password')); ?>">
                        <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="invalid-feedback" role="alert">
                                <?php echo e($message); ?>

                            </div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <label class="custom-control custom-checkbox mt-4">
                        <input class="custom-control-input" type="checkbox" name="remember" id="remember"
                            <?php echo e(old('remember') ? 'checked' : ''); ?>>
                        <span class="custom-control-label">
                            <?php echo e(__('lang.remember-me')); ?>

                        </span>
                    </label>


                    <div class="container-login100-form-btn">
                        <button type="submit" class="login100-form-btn btn-primary">
                            <?php echo e(__('lang.sign-in')); ?>

                        </button>
                    </div>
                </form>
                <?php if(Route::has('password.request')): ?>
                    <div class="text-end pt-1 my-2">
                        <p class="mb-0">
                            <a href="<?php echo e(route('password.request')); ?>" class="text-primary ms-1">
                                <?php echo e(__('lang.forgot-password?')); ?>

                            </a>
                        </p>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\simontov-vepro\simontov-vepro\resources\views/auth/login.blade.php ENDPATH**/ ?>