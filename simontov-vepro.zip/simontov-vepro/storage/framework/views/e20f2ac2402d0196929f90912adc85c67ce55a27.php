<footer class="footer">
    <div class="container">
        <div class="row align-items-center flex-row-reverse">
            <div class="col-md-12 col-sm-12 text-center">
                Copyright © <?php echo e(\Carbon\Carbon::now()->format('Y')); ?> <a
                    href="www.vepronusapersada.com">SiMontoV By Vepro Nusa Persada</a>. All rights reserved
            </div>
        </div>
    </div>
</footer>
<?php /**PATH C:\xampp\htdocs\simontov-vepro\simontov-vepro\resources\views/components/footer.blade.php ENDPATH**/ ?>