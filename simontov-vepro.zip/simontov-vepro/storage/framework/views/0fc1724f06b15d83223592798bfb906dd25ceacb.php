<footer class="footer">
    <div class="container">
        <div class="row align-items-center flex-row-reverse">
            <div class="col-md-12 col-sm-12 text-center">
                Copyright © <?php echo e(\Carbon\Carbon::now()->format('Y')); ?> <a
                    href="javascript:void(0);"><?php echo e(config('app.name')); ?></a>. All rights reserved
            </div>
        </div>
    </div>
</footer>
<?php /**PATH C:\xampp\htdocs\mss-app\resources\views/components/footer.blade.php ENDPATH**/ ?>