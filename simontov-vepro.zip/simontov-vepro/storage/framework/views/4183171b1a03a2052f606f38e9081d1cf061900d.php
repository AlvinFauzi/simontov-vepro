<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <!-- META DATA -->
    <meta charset="UTF-8">
    <meta name='viewport' content='width=device-width, initial-scale=1.0, user-scalable=0'>
    <meta http-equiv="X-UA-Compatible" content="IE=edge">

    <!-- FAVICON -->
    <link rel="shortcut icon" type="image/x-icon" href="<?php echo e(asset('images/logo_sedang.png')); ?>" />

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <meta name="app-url" content="<?php echo e(env('MIX_URL')); ?>">

    <meta name="user-session" content="<?php echo e(auth()->user()->id); ?>">

    <!-- TITLE -->
    <title><?php echo e(str_replace('-', ' ', config('app.name', 'Laravel'))); ?></title>


    <link rel="stylesheet" href="<?php echo e(asset('css/main.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/style.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/icons.css')); ?>">

    <link id="theme" rel="stylesheet" type="text/css" media="all" href="<?php echo e(asset('assets/colors/color1.css')); ?>" />


    <?php echo $__env->yieldContent('styles'); ?>

    <script>
        window.success = {
            save: '<?php echo e(__('messages.success.save')); ?>',
            update: '<?php echo e(__('messages.success.update')); ?>',
            delete: '<?php echo e(__('messages.success.delete')); ?>',
            find: '<?php echo e(__('messages.success.find')); ?>',
            title: '<?php echo e(__('messages.success.title')); ?>',
        }

        window.button = {
            save: '<?php echo e(__('messages.button.save')); ?>',
            update: '<?php echo e(__('messages.button.update')); ?>',
            delete: '<?php echo e(__('messages.button.delete')); ?>',
            find: '<?php echo e(__('messages.button.find')); ?>',
            deleteYes: '<?php echo e(__('messages.button.deleteYes')); ?>',
            deleteNo: '<?php echo e(__('messages.button.deleteNo')); ?>',
        }

        window.modal = {
            new: '<?php echo e(__('messages.modal.new')); ?>',
            update: '<?php echo e(__('messages.modal.update')); ?>',
            detail: '<?php echo e(__('messages.modal.detail')); ?>',
        }

        window.modalAlert = {
            alert: '<?php echo e(__('messages.delete.alert')); ?>',
            alertText: '<?php echo e(__('messages.delete.alertText')); ?>',
            failed: '<?php echo e(__('messages.delete.failed')); ?>',
            unauthorize: '<?php echo e(__('messages.delete.unauthorize')); ?>',
        }
    </script>

</head>

<body class="<?php echo e(session()->get('theme') ?? 'light-mode'); ?>">


    <!-- GLOBAL-LOADER -->
    <div id="global-loader">
        <img src="<?php echo e(asset('assets')); ?>/images/loader.svg" class="loader-img" alt="Loader">
    </div>

    <!-- /GLOBAL-LOADER -->


    <!-- PAGE -->
    <div class="page">
        <div class="page-main">


            <!-- HEADER -->
            <?php echo $__env->make('components.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <!-- End HEADER -->


            <!-- Mobile Header -->
            <?php echo $__env->make('components.mobile-header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <!-- /Mobile Header -->


            <!--/Horizontal-main -->
            <div class="sticky">
                <div class="horizontal-main hor-menu clearfix">
                    <div class="horizontal-mainwrapper container clearfix">
                        <!--Nav-->
                        <?php echo $__env->make('components.horizontal-menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <!--Nav-->
                    </div>
                </div>
            </div>

            <!--/Horizontal-main -->


            <!--app-content open-->
            <div class="app-content hor-content">
                <div class="container">

                    <!-- PAGE-HEADER -->
                    <?php if(!Request::is('home')): ?>
                        <div class="page-header">
                            <div>
                                <h1 class="page-title">
                                    <?php echo e(config('app.name', 'atqiyacode')); ?>

                                </h1>
                                <?php echo e(Breadcrumbs::render()); ?>

                            </div>
                            <?php echo $__env->yieldContent('button-add'); ?>
                        </div>
                    <?php else: ?>
                        <div class="my-3">
                        </div>
                    <?php endif; ?>

                    <!-- PAGE-HEADER END -->

                    <?php echo $__env->yieldContent('content'); ?>

                    <div id="container-tester"></div>

                    <?php echo $__env->yieldContent('modal'); ?>

                </div>
                <!-- CONTAINER CLOSED -->
            </div>
        </div>


        <!-- FOOTER -->
        <?php echo $__env->make('components.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- FOOTER CLOSED -->
    </div>


    <!-- BACK-TO-TOP -->
    <a href="#top" id="back-to-top"><i class="fa fa-angle-up"></i></a>

    <script src="<?php echo e(asset('js/main.js')); ?>"></script>

    <?php echo $__env->yieldContent('scripts'); ?>

    <script src="<?php echo e(mix('js/app.js')); ?>" defer></script>
</body>

</html>
<?php /**PATH C:\xampp\htdocs\mss-app_1\resources\views/layouts/app.blade.php ENDPATH**/ ?>